package com.novanow.client;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

public class NovaSplashScreen extends Activity{

	
//TODO when trying to connect, by pressing the back button cancel the request so there is no error.
//TODO if unable to connect have a different error message
	
	public static final String PREFS1 = "Prefs2File";
	//public static final String URL = "http://10.0.2.2/testDemo.php";
	//public static final String URL = "http://jollyprop.dnsdynamic.com/testDemo.php";  //"http://10.0.2.2/testDemo.php"
	public static final String URL = "http://192.168.1.9/holidays.php";
    private ArrayList<Item> myList;
	private DateFormat f1;
	private DateFormat f2;
	private String curDateitem=null;
	ProgressBar b;
	SimpleDateFormat inFmt;
	SimpleDateFormat outFmt;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.loading_screen);
		
	    b = (ProgressBar) findViewById(R.id.marker_progress);
		myList = new ArrayList<Item>();
		
		inFmt = new SimpleDateFormat("yyyy-mm-dd");
		outFmt = new SimpleDateFormat("mm/dd/yyyy");

		new AsyncLoad1().execute(URL);
	}
	
	//background thread that loads the data from server to phone in JSON format
 	private class AsyncLoad1 extends AsyncTask<Object, Void, JSONArray>{
 		
 		@Override
 		protected void onPreExecute(){
            ProgressBar b = (ProgressBar) findViewById(R.id.marker_progress);
            b.setVisibility(View.VISIBLE);
 		}
 		
 		@Override
 		protected JSONArray doInBackground(Object... args){
 			//initialize
 			InputStream is = null;
 			String result = "";
 			JSONArray jArray = null;
 			
 			try{
 				HttpClient httpclient = new DefaultHttpClient();
 				HttpPost httppost = new HttpPost((String)args[0]);

 				HttpResponse response = httpclient.execute(httppost);
 				HttpEntity entity = response.getEntity();
 				is = entity.getContent();
 			
 			}catch(Exception e){
 				Log.e("log_tag", "Error in http connection"+e.toString());
 			}
 			//convert response to string
 			try{
 				BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
 				StringBuilder sb = new StringBuilder();
 				sb.append(reader.readLine() + "\n");
 				String line="";
 				
 				while ((line = reader.readLine()) != null) {
 					sb.append(line + "\n");
 				}
 				is.close();
 				result=sb.toString();

 			}catch(Exception e){
 				Log.e("log_tag", "Error converting result "+e.toString());
 			}

 			//try parse the string to a JSON object
 			try{
 		        	jArray = new JSONArray(result);
 			}catch(JSONException e){
 				Log.e("log_tag", "Error parsing data "+e.toString());
 			}

 			return jArray;
 		}
 		
 		protected void onPostExecute(JSONArray param){
 			/**Parses the JSON Array into ArrayList of items */	
   			
 			try{
 				JSONObject json_data=null;
 				EntryItem enItem = null;
                Bitmap bmp;

 				for(int i=0;i<param.length();i++){
 					json_data = param.getJSONObject(i);
 					enItem = new EntryItem();
 					
 					enItem.setName(json_data.getString("Name"));
 					enItem.setDescription(json_data.getString("Description"));
 					String sDate = json_data.getString("Start_Date");
 					String rep = null;
                /*
                    String image = json_data.getString("Picture");
                    byte[] imageBytes = Base64.decode(image.getBytes(),0);
                    bmp = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                    int width = 100;
                    int height = 100;
                    Bitmap resizedBitMap = Bitmap.createScaledBitmap(bmp, width, height, true);
                    enItem.seteImage(resizedBitMap);
                */
 					try {
 						 sDate = outFmt.format(inFmt.parse(sDate));
 						 sDate = sDate.substring(0, sDate.lastIndexOf("/"));
 						 rep = sDate.substring(0, sDate.indexOf("/"));
 						 rep = getMonthForInt(Integer.parseInt(rep)-1);
 						 sDate = sDate.substring(sDate.indexOf("/")+1);
 						 sDate = rep + ", " + sDate;
 					} catch (ParseException e) {
 						e.printStackTrace();
 					}
 					enItem.setsDate(sDate);
 	
 					enItem.seteDate(json_data.getString("End_Date"));
 					
 					if(i==0){
 						myList.add(new SectionItem(enItem.getsDate()));
 						myList.add(enItem);
 					}else if (!enItem.getsDate().equals(curDateitem)){
 						myList.add(new SectionItem(enItem.getsDate()));
 						myList.add(enItem);
 					}
 					else{
 						myList.add(enItem);
 					}
 					curDateitem = enItem.getsDate();
 				}
 			}
 			catch(JSONException e1){
 				Toast.makeText(getBaseContext(), "No City Found" ,Toast.LENGTH_LONG).show();
 			}

 			Intent intent = new Intent(NovaSplashScreen.this, NovaNowFinalActivity.class);
   			intent.putExtra("array", myList);
   			startActivity(intent);
   			b.setVisibility(View.INVISIBLE);
   			finish();	
 		}
 	}
 	
 	private String getMonthForInt(int m){
 		String month = "invalid";
 		DateFormatSymbols dfs = new DateFormatSymbols();
 		String[] months = dfs.getMonths();
 		if (m >= 0 && m <= 11){
 			month = months[m];
 		}
 		return month;
 	}
}
