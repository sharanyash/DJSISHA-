package com.novanow.client;

/**
 * Displays the event that was clicked on giving the user a chance to add it to a calendar if wanted.
 */

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ContentValues;
import android.content.DialogInterface;
//import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;


class MyCalendar {
	public String name;
	public String id;

	public MyCalendar(String _name, String _id) {
		name = _name;
		id = _id;
	}
	@Override
	public String toString() {
		return name;
	}
}

public class viewEvent extends Activity {
	
	private TextView nameTextView;
	private TextView descriptionTextView;
	private TextView locationTextView;
	private TextView buildingTextView;
	private TextView roomTextView;
	private TextView sDateTextView;
	private TextView eDateTextView;
	private TextView sTimeTextView;
	private TextView eTimeTextView;
	
	private String name;
	private String description;
	private String location;
	private String building;
	private String room;
	private String sDate;
	private String eDate;
	private String sTime;
	private String eTime;
	private SimpleDateFormat f2;
	
	private TextView m_text_event;

	private Button addCalendarbtn;
	private Button shareButton;
	
	@Override 
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.event);
	
		SimpleDateFormat inFmt = new SimpleDateFormat("yyyy-mm-dd");
		SimpleDateFormat outFmt = new SimpleDateFormat("mm/dd/yyyy");
		
		f2 = new SimpleDateFormat("h:mma");
		
		nameTextView = (TextView) findViewById(R.id.nameTextView);
		descriptionTextView = (TextView) findViewById(R.id.descriptionTextView);
		locationTextView = (TextView) findViewById(R.id.locationTextView);
		buildingTextView = (TextView) findViewById(R.id.buildingTextView);
		roomTextView = (TextView) findViewById(R.id.roomTextView);
		sDateTextView = (TextView) findViewById(R.id.startDateTextView);
		eDateTextView = (TextView) findViewById(R.id.endDateTextView);
		sTimeTextView = (TextView) findViewById(R.id.startTimeTextView);
		eTimeTextView = (TextView) findViewById(R.id.endTimeTextView);
		
		addCalendarbtn = (Button) findViewById(R.id.addcalendarbtn);
		addCalendarbtn.setOnClickListener(addCalendarButtonListener);    
		
		shareButton = (Button) findViewById(R.id.sharebtn);
		shareButton.setOnClickListener(shareButtonListener);
		
		
		Bundle extras = getIntent().getExtras();
		name = extras.getString("name");
		description = extras.getString("description");
		description = description.replaceAll("<.*?>", "");
		description = description.replaceAll("&nbsp;"," ");
		description = description.replaceAll("&amp;", "&");
		
		location = extras.getString("location");
		building = extras.getString("building");
		room = extras.getString("room");
		sDate = extras.getString("sDate");
		
		
		try {
			sDate = outFmt.format(inFmt.parse(sDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		eDate = extras.getString("eDate");
		try{
			eDate = outFmt.format(inFmt.parse(eDate));
		} catch (ParseException e){
			e.printStackTrace();
		}
		
		sTime = extras.getString("sTime");
		eTime = extras.getString("eTime");
		nameTextView.setText(name);
		
		if(!description.equals(""))
			descriptionTextView.setText("Description: " + description);
		else
			descriptionTextView.setText("No Description Provided");
		
		if(!location.equals(""))
			locationTextView.setText("Location information: \n" + location);
		else
			locationTextView.setText("No location provided");
		
		if(!building.equals(""))
			buildingTextView.setText(building);
		else
			buildingTextView.setText("No building provided");
		
		roomTextView.setText(room);
		sDateTextView.setText("Start Date: " + sDate);
		eDateTextView.setText("End Date: " + eDate);
		
		sTimeTextView.setText("Start Time: " + sTime);
		
		if(eTime != null)
			eTimeTextView.setText("End Time: " + eTime);
		
	}

   // @Override
    protected void onListItemClick(ListView l, View v, int position, long id){
    /*    if(!myList.get(position).isSection()){
            EntryItem item = (EntryItem)myList.get(position);
            Intent getMore = new Intent(v.getContext(), viewEvent.class);
            getMore.putExtra("name", item.getName());
            getMore.putExtra("description", item.getDescription());
            getMore.putExtra("location", item.getLocation());
            getMore.putExtra("building", item.getBuilding());
            getMore.putExtra("room", item.getRoom());
            getMore.putExtra("sDate", item.getsDate());
            getMore.putExtra("eDate", item.geteDate());
            getMore.putExtra("sTime", item.getsTime());
            getMore.putExtra("eTime", item.geteTime());
            startActivity(getMore);
        }
        super.onListItemClick(l, v, position, id);  */
    }

	// create the Activity's menu from a menu resource XML file
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       super.onCreateOptionsMenu(menu);
       MenuInflater inflater = getMenuInflater();
       inflater.inflate(R.menu.view_calendar_menu, menu);
       inflater.inflate(R.menu.view_share_menu, menu);
       return true;
    } 
     
   @Override
    public boolean onOptionsItemSelected(MenuItem item) {
	   switch(item.getItemId()){
	   case R.id.calendarItem:
	       /*get calendar list and populate the view*/
		   getCalendars();
		
		   ArrayAdapter l_arrayAdapter = new ArrayAdapter(this.getApplicationContext(), 
				   android.R.layout.select_dialog_singlechoice, m_calendars);
		   AlertDialog.Builder b = new Builder(this);
		   b.setSingleChoiceItems(l_arrayAdapter, 0, new DialogInterface.OnClickListener(){
			   @Override
			   public void onClick(DialogInterface dialog, int id){
				   dialog.dismiss();
				   m_selectedCalendarId = m_calendars[id].id;
				   addEvent();
				   Toast toast = Toast.makeText(getApplicationContext(), "Event Added", Toast.LENGTH_SHORT);
				   toast.show();
			   }
		   });
		   b.show();
		   
		   return super.onOptionsItemSelected(item);
		
	   case R.id.shareItem:
		   Intent intent = new Intent(Intent.ACTION_SEND);
		   intent.setType("text/plain");
		   intent.putExtra(Intent.EXTRA_SUBJECT, nameTextView.getText().toString());
		   intent.putExtra(Intent.EXTRA_TEXT, descriptionTextView.getText().toString());
		   startActivity(Intent.createChooser(intent, "Share with:"));
		   return super.onOptionsItemSelected(item);
		   
	   default:
    	   break;
       }
       return true;
    } 
   
   //Select button listener
    OnClickListener addCalendarButtonListener = new OnClickListener(){
    	
		@Override
    	public void onClick(View v){
    		  
			getCalendars();
    		   ArrayAdapter l_arrayAdapter = new ArrayAdapter(v.getContext(), 
    				   android.R.layout.select_dialog_singlechoice, m_calendars);
    		   AlertDialog.Builder b = new Builder(v.getContext());
    		   b.setSingleChoiceItems(l_arrayAdapter, 0, new DialogInterface.OnClickListener(){
    			   @Override
    			   public void onClick(DialogInterface dialog, int id){
    				   dialog.dismiss();
    				   m_selectedCalendarId = m_calendars[id].id;
    				   addEvent();
    				   Toast toast = Toast.makeText(getApplicationContext(), "Event Added", Toast.LENGTH_SHORT);
    				   toast.show();
    			   }
    		   });
    		b.show();   
    	}
    };
    
    //Select the share button
    OnClickListener shareButtonListener = new OnClickListener(){
    	@Override
    	public void onClick(View v){
    		  Intent intent = new Intent(Intent.ACTION_SEND);
   		   intent.setType("text/plain");
   		   intent.putExtra(Intent.EXTRA_SUBJECT, nameTextView.getText().toString());
   		   intent.putExtra(Intent.EXTRA_TEXT, descriptionTextView.getText().toString());
   		   startActivity(Intent.createChooser(intent, "Share with:"));
    	}
    };
   
   
	/****************************************************************
	 * Data part
	 */
	/*retrieve a list of available calendars*/
	private MyCalendar m_calendars[];
	private String m_selectedCalendarId = "0";
	private void getCalendars() {
		String[] l_projection = new String[]{"_id", "displayName"};
		Uri l_calendars;
		if (Build.VERSION.SDK_INT >= 8) {
			l_calendars = Uri.parse("content://com.android.calendar/calendars");
		} else {
			l_calendars = Uri.parse("content://calendar/calendars");
		}
		Cursor l_managedCursor = this.managedQuery(l_calendars, l_projection, null, null, null);	//all calendars
		if (l_managedCursor.moveToFirst()) {
			m_calendars = new MyCalendar[l_managedCursor.getCount()];
			String l_calName;
			String l_calId;
			int l_cnt = 0;
			int l_nameCol = l_managedCursor.getColumnIndex(l_projection[1]);
			int l_idCol = l_managedCursor.getColumnIndex(l_projection[0]);
			do {
				l_calName = l_managedCursor.getString(l_nameCol);
				l_calId = l_managedCursor.getString(l_idCol);
				m_calendars[l_cnt] = new MyCalendar(l_calName, l_calId);
				++l_cnt;
			} while (l_managedCursor.moveToNext());
		}
	}
	/*add an event to calendar*/
	private void addEvent() {
		ContentValues l_event = new ContentValues();
		l_event.put("calendar_id", m_selectedCalendarId);
		l_event.put("title", nameTextView.getText().toString());
		l_event.put("description", descriptionTextView.getText().toString());
		l_event.put("eventLocation", buildingTextView.getText().toString() + " " + roomTextView.getText().toString());
		
		String monthString = sDate.substring(0, sDate.indexOf(","));
		int mo = monthString.equals("January")? Calendar.JANUARY :
					monthString.equals("February") ? Calendar.FEBRUARY :
					monthString.equals("March") ? Calendar.MARCH :
					monthString.equals("April") ? Calendar.APRIL :
					monthString.equals("May") ? Calendar.MAY :
					monthString.equals("June") ? Calendar.JUNE :
					monthString.equals("July") ? Calendar.JULY :
					monthString.equals("August") ? Calendar.AUGUST :
					monthString.equals("September") ? Calendar.SEPTEMBER :
					monthString.equals("October") ? Calendar.OCTOBER :
					monthString.equals("November") ? Calendar.NOVEMBER :
					monthString.equals("December") ? Calendar.DECEMBER : 0;
		
		int day = Integer.parseInt(sDate.substring(sDate.indexOf(",")+1).trim());
		Date finalDate = null;
		Date endDate = null;
		
		try {
			Date d = f2.parse(sTime);
			
			Calendar tCal = Calendar.getInstance();
			tCal.setTime(d);
			
			Calendar dCal = Calendar.getInstance();
			dCal.set(2012, mo, day);
			
			dCal.set(Calendar.HOUR_OF_DAY, tCal.get(Calendar.HOUR_OF_DAY));
			dCal.set(Calendar.MINUTE, tCal.get(Calendar.MINUTE));
			dCal.set(Calendar.SECOND, tCal.get(Calendar.SECOND));
			dCal.set(Calendar.MILLISECOND, tCal.get(Calendar.MILLISECOND));
			finalDate = dCal.getTime();
			
			if(!eTime.equals("")){
				Calendar endCal = Calendar.getInstance();
				Calendar eCal =Calendar.getInstance();
				Date e = f2.parse(eTime);
				endCal.setTime(e);
				
				eCal.set(2012, mo, day);
				eCal.set(Calendar.HOUR_OF_DAY, endCal.get(Calendar.HOUR_OF_DAY));
				eCal.set(Calendar.MINUTE, endCal.get(Calendar.MINUTE));
				eCal.set(Calendar.SECOND, endCal.get(Calendar.SECOND));
				eCal.set(Calendar.MILLISECOND, endCal.get(Calendar.MILLISECOND));
				endDate = eCal.getTime();
			}
			} catch (ParseException e) {
				e.printStackTrace();
			}
		
		l_event.put("dtstart", finalDate.getTime());
		if(!eTime.equals(""))
			l_event.put("dtend", endDate.getTime());
		else
			l_event.put("dtend", System.currentTimeMillis() + 1800*1000);
		l_event.put("allDay", 0);
		//status: 0~ tentative; 1~ confirmed; 2~ canceled
		l_event.put("eventStatus", 1);
		//0~ default; 1~ confidential; 2~ private; 3~ public
		l_event.put("visibility", 0);
		//0~ opaque, no timing conflict is allowed; 1~ transparency, allow overlap of scheduling
		l_event.put("transparency", 0);
		//0~ false; 1~ true
		l_event.put("hasAlarm", 1);
		Uri l_eventUri;
		if (Build.VERSION.SDK_INT >= 8) {
			l_eventUri = Uri.parse("content://com.android.calendar/events");
		} else {
			l_eventUri = Uri.parse("content://calendar/events");
		}
		Uri l_uri = this.getContentResolver().insert(l_eventUri, l_event);
		Log.v("++++++test", l_uri.toString());
	}

	//get a list of events 
	private void getLastThreeEvents() {
		Uri l_eventUri;
		if (Build.VERSION.SDK_INT >= 8) {
			l_eventUri = Uri.parse("content://com.android.calendar/events");
		} else {
			l_eventUri = Uri.parse("content://calendar/events");
		}
		String[] l_projection = new String[]{"title", "dtstart", "dtend"};
		Cursor l_managedCursor = this.managedQuery(l_eventUri, l_projection, "calendar_id=" + m_selectedCalendarId, null, "dtstart DESC, dtend DESC");
		//Cursor l_managedCursor = this.managedQuery(l_eventUri, l_projection, null, null, null);
		if (l_managedCursor.moveToFirst()) {
			int l_cnt = 0;
			String l_title;
			String l_begin;
			String l_end;
			StringBuilder l_displayText = new StringBuilder();
			int l_colTitle = l_managedCursor.getColumnIndex(l_projection[0]);
			int l_colBegin = l_managedCursor.getColumnIndex(l_projection[1]);
			int l_colEnd = l_managedCursor.getColumnIndex(l_projection[1]);
			do {
				l_title = l_managedCursor.getString(l_colTitle);
				l_begin = getDateTimeStr(l_managedCursor.getString(l_colBegin));
				l_end = getDateTimeStr(l_managedCursor.getString(l_colEnd));
				l_displayText.append(l_title + "\n" + l_begin + "\n" + l_end + "\n----------------\n");
				++l_cnt;
			} while (l_managedCursor.moveToNext() && l_cnt < 3);
			m_text_event.setText(l_displayText.toString());
		}
	}
	/************************************************
	 * utility part
	 */
	private static final String DATE_TIME_FORMAT = "yyyy MMM dd, HH:mm:ss";
	public static String getDateTimeStr(int p_delay_min) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
		if (p_delay_min == 0) {
			return sdf.format(cal.getTime());
		} else {
			Date l_time = cal.getTime();
			l_time.setMinutes(l_time.getMinutes() + p_delay_min);
			return sdf.format(l_time);
		}
	}
	public static String getDateTimeStr(String p_time_in_millis) {
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
		Date l_time = new Date(Long.parseLong(p_time_in_millis));
		return sdf.format(l_time);
	}
}
