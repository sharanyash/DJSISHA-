package com.novanow.client;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ViewHoliday extends Activity
{
    private TextView nameTextView;
    private TextView descriptionTextView;
    private TextView sDateTextView;
    private TextView eDateTextView;

    private String name;
    private String description;
    private String sDate;
    private String eDate;
    private SimpleDateFormat f2;

    private Button addCalendarbtn;
    private Button shareButton;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.holiday);

        SimpleDateFormat inFmt = new SimpleDateFormat("yyyy-mm-dd");
        SimpleDateFormat outFmt = new SimpleDateFormat("mm/dd/yyyy");

        f2 = new SimpleDateFormat("h:mma");

        nameTextView = (TextView) findViewById(R.id.nameTextView);
        descriptionTextView = (TextView) findViewById(R.id.descriptionTextView);
        sDateTextView = (TextView) findViewById(R.id.startDateTextView);
        eDateTextView = (TextView) findViewById(R.id.endDateTextView);

        addCalendarbtn = (Button) findViewById(R.id.addcalendarbtn);
        addCalendarbtn.setOnClickListener(addCalendarButtonListener);

        shareButton = (Button) findViewById(R.id.sharebtn);
        shareButton.setOnClickListener(shareButtonListener);


        Bundle extras = getIntent().getExtras();
        name = extras.getString("name");
        description = extras.getString("description");
        sDate = extras.getString("sDate");

        try {
            sDate = outFmt.format(inFmt.parse(sDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        eDate = extras.getString("eDate");
        try{
            eDate = outFmt.format(inFmt.parse(eDate));
        } catch (ParseException e){
            e.printStackTrace();
        }
        nameTextView.setText(name);

        if(!description.equals(""))
            descriptionTextView.setText("Description: " + description);
        else
            descriptionTextView.setText("No Description Provided");

        sDateTextView.setText("Start Date: " + sDate);
        eDateTextView.setText("End Date: " + eDate);
    }

    // create the Activity's menu from a menu resource XML file
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.view_calendar_menu, menu);
        inflater.inflate(R.menu.view_share_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.calendarItem:
	       /*get calendar list and populate the view*/
                return super.onOptionsItemSelected(item);

            case R.id.shareItem:
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, nameTextView.getText().toString());
                intent.putExtra(Intent.EXTRA_TEXT, descriptionTextView.getText().toString());
                startActivity(Intent.createChooser(intent, "Share with:"));
                return super.onOptionsItemSelected(item);

            default:
                break;
        }
        return true;
    }

    //Select button listener
    View.OnClickListener addCalendarButtonListener = new View.OnClickListener(){

        @Override
        public void onClick(View v){

        }
    };

    //Select the share button
    View.OnClickListener shareButtonListener = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, nameTextView.getText().toString());
            intent.putExtra(Intent.EXTRA_TEXT, descriptionTextView.getText().toString());
            startActivity(Intent.createChooser(intent, "Share with:"));
        }
    };
}
