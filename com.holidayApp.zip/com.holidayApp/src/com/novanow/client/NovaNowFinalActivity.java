package com.novanow.client;

import java.util.ArrayList;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

public class NovaNowFinalActivity extends ListActivity {

	private ArrayList<Item> myList;
	
	@SuppressWarnings("null")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		Bundle bundle = getIntent().getExtras();
		myList = (ArrayList<Item>) bundle.get("array");
		
	    EntryAdapter adapter = new EntryAdapter(this, myList);
		setListAdapter(adapter);
	}
	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id){
		if(!myList.get(position).isSection()){
			EntryItem item = (EntryItem)myList.get(position);
			Intent getMore = new Intent(v.getContext(), ViewHoliday.class);
			getMore.putExtra("name", item.getName());
			getMore.putExtra("description", item.getDescription());
			getMore.putExtra("sDate", item.getsDate());
			getMore.putExtra("eDate", item.geteDate());
			startActivity(getMore);
		}
		super.onListItemClick(l, v, position, id);
	}
	
	 // create the Activity's menu from a menu resource XML file
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       super.onCreateOptionsMenu(menu);
       MenuInflater inflater = getMenuInflater();
       inflater.inflate(R.menu.view_event_menu, menu);
       inflater.inflate(R.menu.view_categories_menu, menu);
       return true;
    }
}
