package com.novanow.client;

import android.graphics.Bitmap;
import android.widget.ImageView;

public class EntryItem implements Item{

	public String name;
	public String description;
	public String category;
	public String location;
	public String building;
	public String room;
	public String sDate;
	public String eDate;
	public String sTime;
	public String eTime;
    public Bitmap eImage;

	public EntryItem() {		
		name = null;
		description = null;
		category = null;
		location = null;
		building = null;
		room = null;
		sDate = null;
		eDate = null;
		sTime = null;
		eTime = null;
	    eImage = null;
    }

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getsDate() {
		return sDate;
	}
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	public String geteDate() {
		return eDate;
	}
	public void seteDate(String eDate) {
		this.eDate = eDate;
	}
	public String getsTime() {
		return sTime;
	}
	public void setsTime(String sTime) {
		this.sTime = sTime;
	}
	public String geteTime() {
		return eTime;
	}
	public void seteTime(String eTime) {
		this.eTime = eTime;
	}

    public Bitmap geteImage(){
        return eImage;
    }

    public void seteImage(Bitmap eImage){
        this.eImage = eImage;
    }

	@Override
	public boolean isSection() {
		return false;
	}
}
