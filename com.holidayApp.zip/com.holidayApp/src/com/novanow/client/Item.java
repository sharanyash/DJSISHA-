package com.novanow.client;

import java.io.Serializable;

public interface Item extends Serializable{
	public boolean isSection();
}
